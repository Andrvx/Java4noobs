// objeto poligono -- base altura apotema radio diagonales
public class Main {
    public static void main(String[] args) {

    }
}